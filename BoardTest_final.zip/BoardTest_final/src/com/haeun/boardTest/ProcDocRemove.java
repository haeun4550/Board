package com.haeun.boardTest;

import com.haeun.boardTest.data.Data;
//import com.haeun.boardTest.data.Post;
import com.haeun.boardUtil.Scan;

public class ProcDocRemove {
	public static void run() {
		if(Data.posts.size()<=0) {
			System.out.println("게시글이 없습니다.");
		}else {
		String cmd = Scan.rl("삭제할 게시글 번호를 입력해주세요.");
		for(int i=0; i<Data.posts.size();i++){
			if(!cmd.equals(Data.posts.get(i).instanceNo+"")){
				System.out.println("존재하지 않는 게시글번호입니다.");
			}
		else if(cmd.equals(Data.posts.get(i).instanceNo+"")) {
				Data.posts.remove(i);
			}
		}
}
}
}

