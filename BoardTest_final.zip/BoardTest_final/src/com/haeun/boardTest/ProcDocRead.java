package com.haeun.boardTest;

import com.haeun.boardTest.data.Data;
import com.haeun.boardTest.data.Post;
import com.haeun.boardUtil.Scan;

public class ProcDocRead {
	public static void run() {
		if(Data.posts.size()<=0) {
			System.out.println("게시글이 없습니다.");
		}else {
		String cmd = Scan.rl("읽을 게시글번호를 입력해주세요.");
		for(Post p:Data.posts) {
			if(!cmd.equals(p.instanceNo+"")) {
				System.out.println("존재하지 않는 게시글번호입니다.");
			}
		else if(cmd.equals(p.instanceNo+"")) {
				p.hit = p.hit+1;
				p.readInfo();
			}
		}
}
}
}
