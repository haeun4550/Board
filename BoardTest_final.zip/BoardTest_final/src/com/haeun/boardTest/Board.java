package com.haeun.boardTest;

import com.haeun.boardTest.data.Data;

public class Board {
	public void run() {
		Data.loadData();
		Display.title();
		ProcMenu.run();
	}
}
