package com.haeun.boardTest.data;
import java.time.LocalDate;
public class Post {
	
	public String title;
	public String content;
	public String writer;
	public static int no;
	public int instanceNo;
	public int hit;
	public  String date;
	
	public Post(String title, String content, String writer,int hit) {
		this.title = title;
		this.content = content;
		this.writer = writer;
		this.hit = hit;
		no = no+1;
		instanceNo = no;
		LocalDate now = LocalDate.now();
		date = now.toString(); 
	}
	
	public void listInfo() {
		System.out.print("번호:"+instanceNo);
		System.out.print(" 제목:"+title);
		System.out.print(" 작성자:"+writer);
		System.out.print(" 조회수:"+hit);
		System.out.println(" 작성일:"+date);
	}
	public void readInfo() {
		System.out.print(" 제목:"+title);
		System.out.print(" 작성자:"+writer);
		System.out.print(" 조회수:"+hit);
		System.out.println(" 작성일:"+date);
		System.out.println(" 내용:"+content);
	}
	
}
