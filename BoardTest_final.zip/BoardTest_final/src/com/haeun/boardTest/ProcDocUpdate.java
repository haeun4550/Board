package com.haeun.boardTest;

import com.haeun.boardTest.data.Data;
import com.haeun.boardTest.data.Post;
import com.haeun.boardUtil.Scan;

public class ProcDocUpdate {
	public static void run() {
		if(Data.posts.size()<=0) {
			System.out.println("게시글이 없습니다.");
		}else {
		String num = Scan.rl("수정할 게시글 번호를 입력해주세요.");
		for(Post p:Data.posts) {
			if(!num.equals(p.instanceNo+"")) {
				System.out.println("존재하지 않는 게시글번호입니다.");
			}else {
		
		loop:
			while(true) {
				String cmd = Scan.rl("수정할 항목을 선택해주세요. [1.제목/2.내용/3.작성자/e.수정종료]");
				switch(cmd) {
				case "1" :
					String title = Scan.rl("제목");
					for(Post p1:Data.posts) {
						if(num.equals(p1.instanceNo+"")) {
							p1.title= title;
						}
					}
					break;
				case "2" :
					String content = Scan.rl("내용");
					for(Post p1:Data.posts) {
						if(num.equals(p1.instanceNo+"")) {
							p1.content= content;
						}
					}
					break;
				case "3" :
					String writer = Scan.rl("작성자");
					for(Post p1:Data.posts) {
						if(num.equals(p1.instanceNo+"")) {
							p1.writer= writer;
						}
					}
					break;
				case "e" :
					break loop;
				default :
					System.out.println("번호를 다시 입력해주세요.");
					break;
				}
			}
			}
		
}
}
}
}
