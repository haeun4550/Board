package com.haeun.boardTest;

import com.haeun.boardTest.data.Data;
import com.haeun.boardTest.data.Post;
import com.haeun.boardUtil.Scan;

public class ProcDocWrite {
	public static void run() {
		
		String title;
		String content;
		String writer;
		
		while(true) {
			title = Scan.rl("제목");
			break;
		}
		while(true) {
			content = Scan.rl("내용");
			break;
		}
		while(true) {
			writer = Scan.rl("작성자");
			break;
		}
		
		Post p = new Post(title, content, writer,0);
		Data.posts.add(p);
	}
}
