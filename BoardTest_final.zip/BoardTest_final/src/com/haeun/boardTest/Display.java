package com.haeun.boardTest;

public class Display {
	public static void title() {
		System.out.println("=================");
		System.out.println("게시판만들기테스트제출용");
		System.out.println("=================");
	}
	
	public static void menuList() {
		System.out.println("-------------------------------------------------");
		System.out.println("[1.글리스트/2.글읽기/3.글쓰기/4.글수정/5.글삭제/e.프로그램종료]");
		System.out.println("-------------------------------------------------");
	}
}
