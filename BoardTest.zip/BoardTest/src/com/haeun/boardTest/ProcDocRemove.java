package com.haeun.boardTest;

import com.haeun.boardTest.data.Data;
//import com.haeun.boardTest.data.Post;
import com.haeun.boardUtil.Scan;

public class ProcDocRemove {
	public static void run() {
		String cmd = Scan.rl("삭제할 게시글 번호를 입력해주세요.");
		for(int i=0; i<Data.posts.size();i++){
			if(cmd.equals(Data.posts.get(i).instanceNo+"")) {
				Data.posts.remove(i);
			}
		}
}
}
