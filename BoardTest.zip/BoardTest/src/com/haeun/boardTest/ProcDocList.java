package com.haeun.boardTest;

import com.haeun.boardTest.data.Data;
import com.haeun.boardTest.data.Post;

public class ProcDocList {
	public static void run() {
		if(Data.posts.size()<=0) {
			System.out.println("게시글이 없습니다.");
		}else {
		for(Post p:Data.posts) {
				p.listInfo();
			}
		}
	}
}
