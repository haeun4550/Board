package com.haeun.boardTest;

import com.haeun.boardTest.data.Data;
import com.haeun.boardTest.data.Post;
import com.haeun.boardUtil.Scan;

public class ProcDocUpdate {
	public static void run() {
		String num = Scan.rl("수정할 게시글 번호를 입력해주세요.");
		loop:
			while(true) {
				String cmd = Scan.rl("수정할 항목을 선택해주세요. [1.제목/2.내용/3.작성자/e.수정종료]");
				switch(cmd) {
				case "1" :
					String title = Scan.rl("제목");
					for(Post p:Data.posts) {
						if(num.equals(p.instanceNo+"")) {
							p.title= title;
						}
					}
					break;
				case "2" :
					String content = Scan.rl("내용");
					for(Post p:Data.posts) {
						if(num.equals(p.instanceNo+"")) {
							p.content= content;
						}
					}
					break;
				case "3" :
					String writer = Scan.rl("작성자");
					for(Post p:Data.posts) {
						if(num.equals(p.instanceNo+"")) {
							p.writer= writer;
						}
					}
					break;
				case "e" :
					break loop;
				default :
					System.out.println("번호를 다시 입력해주세요.");
					break;
				}
			}
		
}
}
