package com.haeun.boardTest;
import com.haeun.boardUtil.Scan;

public class ProcMenu {
	public static void run() {
		loop:
		while(true) {
			Display.menuList();
			String cmd = Scan.rl("번호를 입력해주세요.");
			switch(cmd) {
			case "1":
				ProcDocList.run();
				break;
			case "2":
				ProcDocRead.run();
				break;
			case "3":
				ProcDocWrite.run();
				break;
			case "4":
				ProcDocUpdate.run();
				break;
			case "5":
				ProcDocRemove.run();
				break;
			case "e":
				break loop;
			default:
				System.out.println("옳은 번호를 입력해주세요.");
				break;
			}
		}
	}
}
